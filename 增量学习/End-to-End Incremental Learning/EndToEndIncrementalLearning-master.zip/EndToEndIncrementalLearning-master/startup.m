addpath(genpath(pwd));
run ../ResNet-Matconvnet/setup.m


