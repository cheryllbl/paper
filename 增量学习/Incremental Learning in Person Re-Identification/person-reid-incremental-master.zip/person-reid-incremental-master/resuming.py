import torch
PATH = 'log/resnet50-xent-market1501/checkpoint_ep180.pth.tar'
checkpoint = torch.load(PATH)
