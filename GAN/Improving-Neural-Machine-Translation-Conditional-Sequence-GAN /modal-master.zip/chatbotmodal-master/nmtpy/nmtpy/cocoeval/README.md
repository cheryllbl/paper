pycocoevalcap
---

This is a copy from
 https://github.com/tylin/coco-caption/tree/master/pycocoevalcap
