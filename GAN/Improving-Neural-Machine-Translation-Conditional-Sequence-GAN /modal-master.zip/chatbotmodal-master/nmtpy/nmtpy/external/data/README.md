Download METEOR paraphrase files to here using `scripts/get-meteor-data.sh`
before running `python setup.py install`
