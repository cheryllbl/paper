export THEANO_FLAGS=device=cpu

python ../nmtpy/GAN/discriminator-classify.py -c model_conf/discriminator_en_fr_classify.conf